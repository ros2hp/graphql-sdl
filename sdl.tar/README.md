# graph-sdl
Implementation of a schema definition for GraphQL. All documents and types are stored in Dynamodb.
